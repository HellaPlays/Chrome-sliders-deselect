// Background script (empty for this extension since no background tasks are needed)
